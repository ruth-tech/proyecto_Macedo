<?php

    include('../../php/conexion.php');

    session_start();

    // Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
    if (!isset($_SESSION["logueado"])) {
        header("location: ../../index.php?error=debe_loguearse");
        exit;
    }

    if(isset($_POST['id'])){

        $id = $_POST['id'];

        $query = "UPDATE clientes SET estado = 0 WHERE cliente_id = ". $id;

        $result = mysqli_query($conexion,$query);

        if(!$result){
            die('Query failed');
        }

       
        echo "Cliente dado de baja exítosamente";
    }






?>