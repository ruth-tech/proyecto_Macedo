//Prueba de JS
//console.log('Hello Word');

//Comprobar el funcionamiento de jquery
$(document).ready(function(){

    console.log('Jquery is working');

    fetchList();//llamado y ejecucuion de la funcioon que muestra el listado de clientes

    // Listado

    function fetchList(){
        $.ajax({
            url: 'lista.php',
            type: 'GET',
            success: function(response){
                let lista = JSON.parse(response);
                let template = '';
                lista.forEach(lista => {
                    template +=
                    `<tr clienteId="${lista.id}">
                        <td>${lista.id}</td>
                        <td>${lista.cliente}</td>
                        <td>${lista.cuil}</td>
                        <td>${lista.nro_cuenta}</td>
                        <td>
                            <button class="cliente-edit btn btn-warning" data-toggle="modal" data-target=".editarCliente" ><i class="far fa-edit"></i></button>
                        
                            <button class="deleteCliente btn btn-danger"><i class="far fa-trash-alt"></i></button>
                        </td>                    
                    </tr>`
                });
                $("#listadoClientes").html(template);
            }
        });
    }

    // Agregar

    $('#agregar').submit(function(e){
        // Se crea una constante que almacena los datos que llegan desde el formulario
        const postData = {
            nombre: $('#nombre').val(),
            apellido: $('#apellido').val(),
            dni: $('#dni').val(),
            cuil: $('#cuil').val(),
            sexo: $('#sexo').val(),
            fchNac: $('#fchNac').val(),
            nacionalidad: $('#nacionalidad').val(),
            nro_cuenta: $('#nro_cuenta').val(),

        };

        // Se envia los datos a traves del metodo POST

        $.post('cliente-add.php', postData, function(response){
            console.log(response);
            fetchList();

            // Se resetea el formulario luego de haber enviado los datos

            $('#agregar').trigger('reset');
            
        });

        //Con esta linea se esconde el modal de agregar
        $('#agregar').modal('hide');

        //se utiliza para detener una accion por omision
        //Llamar a preventDefault en cualquier momento durante la ejecución, cancela el evento, lo que significa que cualquier acción por defecto que deba producirse como resultado de este evento, no ocurrirá.
        e.preventDefault();
    });

    //Eliminar
    $(document).on('click', '.deleteCliente', function(){
        if(confirm('Estas seguro que desea dar de baja a este cliente?')){
            let element = $(this)[0].parentElement.parentElement;
            let id = $(element).attr('clienteId');
            
            $.post('cliente-delete.php', {id:id}, function(response){
                fetchList();
                console.log(response);
            });
        }
    });

    //Editar
    $(document).on('click', '.cliente-edit', function(){
        let element = $(this)[0].parentElement.parentElement;
        let id = $(element).attr('clienteId');
        

        $.post('cliente-edit.php', {id:id}, function(response){
            console.log(response);
           
            const datos = JSON.parse(response);
            
            $('#clienteId').val(datos.clienteId);
            $('#nombreedit').val(datos.nombre);
            $('#apellidoedit').val(datos.apellido);
            $('#dniedit').val(datos.dni);
            $('#cuiledit').val(datos.cuil);
            $('#sexoedit').val(datos.sexo);
            $('#fchNacedit').val(datos.fchNac);
            $('#nacionalidadedit').val(datos.nacionalidad);
            $('#nro_cuentaedit').val(datos.nro_cuenta);
        });

        $('#editar').submit(function(e){

            const postData = {
                clienteId: $('#clienteId').val(),
                nombre: $('#nombreedit').val(),
                apellido: $('#apellidoedit').val(),
                dni: $('#dniedit').val(),
                cuil: $('#cuiledit').val(),
                sexo: $('#sexoedit').val(),
                fchNac: $('#fchNacedit').val(),
                nacionalidad: $('#nacionalidadedit').val(),
                nro_cuenta: $('#nro_cuentaedit').val(),
    
            };
    
            $.ajax({
                url: 'clientes-update.php',
                data: postData,
                type: 'POST',
                success: function(response){
                    fetchList();
                    console.log(response);
                }
            });
            
            $('#editar').modal('hide');

            e.preventDefault();
        });


    

        // $.post('cliente-update.php', postData, function(response){

        //     console.log(response);

        //     fetchList();

        //     // Se resetea el formulario luego de haber enviado los datos

        //     $('#editar').trigger('reset');
            
        // });
        // //Con esta linea se esconde el modal de agregar
        // $('#editar').modal('hide');

        // //se utiliza para detener una accion por omision
        // //Llamar a preventDefault en cualquier momento durante la ejecución, cancela el evento, lo que significa que cualquier acción por defecto que deba producirse como resultado de este evento, no ocurrirá.
        // e.preventDefault();
    });

 });
