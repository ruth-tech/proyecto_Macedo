<?php
    include('../../php/conexion.php');

    session_start();
    
    // Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
    if (!isset($_SESSION["logueado"])) {
        header("location: ../../index.php?error=debe_loguearse");
        exit;
    }

    if(isset($_POST['clienteId'])){
        $id = $_POST['clienteId'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $dni = $_POST['dni'];
        $cuil = $_POST['cuil'];
        $sexo = $_POST['sexo'];
        $fchNac = $_POST['fchNac'];
        $nacionalidad = $_POST['nacionalidad'];
        $nro_cuenta = $_POST['nro_cuenta'];

    }

    

    $sql = "SELECT * FROM clientes where cliente_id =".$id;

    // si no puedo guardar, redirecciono al listado con mensaje de error
    if (!($rs = mysqli_query($conexion, $sql))) {
        echo 'falla la extraccion de persona id';
        //$mensaje = 'GUARDAR_PERSONA_ERROR';
        //header("location: ../listado.php?mensaje=$mensaje");
        exit;
    }

    $cliente = $rs->fetch_assoc();

    $persona_id = $cliente['rela_persona_fisica'];

    $sql1 = "UPDATE clientes SET cliente_nro_cuenta = ".$nro_cuenta;

     // si no puedo guardar, redirecciono al listado con mensaje de error
     if (!mysqli_query($conexion, $sql1)) {
        echo 'falla la modificacion en lña tabla clientes';
        //$mensaje = 'GUARDAR_PERSONA_ERROR';
        //header("location: ../listado.php?mensaje=$mensaje");
        exit;
    }

    $sql2 = 'UPDATE personas_fisicas set apellidos_persona = "'.$apellido.'", nombres_persona = "'.$nombre.'", persona_sexo = "'.$sexo.'", persona_dni = '.$dni.', persona_cuil = '.$cuil.', persona_fecha_nac = "'.$fchNac.'", persona_nacionalidad = "'.$nacionalidad.'" WHERE persona_fisica_id = '.$persona_id;
    

     // si no puedo guardar, redirecciono al listado con mensaje de error
     if (!mysqli_query($conexion, $sql2)) {
        die($conexion->error);
        echo 'falla la modificacion en la tabla persona';
        //$mensaje = 'GUARDAR_PERSONA_ERROR';
        //header("location: ../listado.php?mensaje=$mensaje");
        exit;
    }

    echo 'Exito al modificar';



?>