<?php
    include('../../php/conexion.php');

    session_start();
      
    // Si no existe la variable de sesión logueado, entonces el usuario debe loguearse.
    if (!isset($_SESSION["logueado"])) {
      header("location: ../../index.php?error=debe_loguearse");
      exit;
    }

    $id = $_POST['id'];

    $sql1 = "SELECT * FROM clientes WHERE cliente_id = ".$id;

    $rs = mysqli_query($conexion, $sql1);

    $cliente = $rs->fetch_assoc();

    $persona_id = $cliente['rela_persona_fisica'];
  
    $nro_cuenta = $cliente['cliente_nro_cuenta'];

    $sql2 = "SELECT * FROM personas_fisicas where persona_fisica_id = ".$persona_id;

    $rs = mysqli_query($conexion, $sql2);

    $json = array();

    while($row = mysqli_fetch_array($rs)){
      $json[] = array(
       'nombre'=>$row['nombres_persona'],
       'apellido'=>$row['apellidos_persona'],
       'dni'=>$row['persona_dni'],
       'cuil'=>$row['persona_cuil'],
       'sexo'=>$row['persona_sexo'],
       'fchNac'=> $row['persona_fecha_nac'],
       'nacionalidad'=>$row['persona_nacionalidad'],
       'nro_cuenta'=>$nro_cuenta,
       'clienteId'=>$id
          
      );
      
        
    }
    $jsonstring = json_encode($json[0]);
    echo $jsonstring;




?>