<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prueba 3</title>

    <!-- ACCESO A NUESTRA CARPETA DE BOOTSTRAP -->
    <link rel="stylesheet" type="text/css" href="\autoparts_system\bootstrap-4.5.0/css/bootstrap.min.css">
    <!-- CDN Jquery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" ></script>
    <!-- CDN BOOTSTRAP (LINK AND SCRIPT) -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" ></script>

    

</head>
<body>

    

    

    <?php require '../../php/menu.php'; ?>
    
    <div class="container-fluid">

        <div class="card border-danger">
            <div class="card-header">
                <div class="btn-group fa-pull-right">
                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#nuevoCliente"><i class="fas fa-plus"></i>
                        Agregar
                    </button>

                </div>
                <h3>Clientes</h3>
                
            </div>
            <!-- Modal AGREGAR -->
            <div class="modal fade" id="nuevoCliente" tabindex="-1" role="dialog" aria-labelledby="newModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>

                        <div class="modal-body">
                            <form role="form" method="post" id="agregar">
                                <h3>Ingrese los datos del cliente</h3>
                                <p>
                                <div class="form-group">
                                    <label>Escriba su nombre: </label>
                                    <input type="text" id="nombre">
                                    </label>
                                    
                                </div>
                                    
                                </p>
                                <p>
                                <div class="form-group">
                                <label>Escriba su apellido </label>
                                    <input type="text" id="apellido" >
                                    </label>
                                    
                                </div>
                                    
                                </p>
                                <p>
                                <div class="form-group">
                                <label>Escriba su DNI:</label>
                                    <input type="text" id="dni" >
                                    </label>
                                    
                                </div>
                                    
                                </p>
                                <p>
                                <div class="form-group">
                                    <label>Escriba su Cuil:</label>
                                    <input type="text" id="cuil" >
                                    </label>
                                    
                                </div>
                                    
                                </p>
                                
                                <p>Genero:
                                <div class="form-group">
                                    <label><input type="radio" id="sexo" value="femenino"> Mujer </label>
                                    <label><input type="radio" id="sexo" value="masculino"> Hombre </label>
                                    <label><input type="radio" id="sexo" value="otro"> Otro </label><br>
                                    
                                </div>                            
                                </p>
                                
                                
                                <p>
                                <div class="form-group">
                                <label>Fecha de Nacimiento</label>
                                    <input type="date" id="fchNac" placeholder="
                                    AAAA/MM/DD">
                                    </label>
                                    
                                </div>
                                    
                                </p>

                                <p>
                                <div class="form-group">
                                <label>Nacionalidad</label>
                                    <input type="text" id="nacionalidad">
                                    </label>
                                    
                                </div>
                                    
                                </p>
                                <p>
                                <div class="form-group">
                                    <label>Nro. de cuenta</label>
                                    <input type="text" id="nro_cuenta" >
                                    </label>
                                </div>
                                
                                </p>
                                
                                <button type="submit" class="btn btn-danger">Agregar</button>

                            </form>
                        </div>

                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal AGREGAR-->

            <div class="card-body text-danger">

                <table class="table table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <td>Id</td>
                            <td>Cliente</td>
                            <td>Cuil</td>
                            <td>Cuenta</td>
                            <td>Acciones</td>
                        </tr>

                    </thead>
                    <tbody id="listadoClientes">

                    </tbody>
                </table>

            </div>

            <!-- Modal EDITAR -->
            <div class="modal fade editarCliente" tabindex="-1" role="dialog" aria-labelledby="newModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>

                        <div class="modal-body">
                            <form role="form" method="post" id="editar">
                                <h3>Modificar los datos del cliente</h3>

                                <input type="hidden" id="clienteId">
                                <p>
                                <div class="form-group">
                                    <label>Escriba su nombre: </label>
                                    <input type="text" id="nombreedit" >
                                    </label>
                                    
                                </div>
                                    
                                </p>
                                <p>
                                <div class="form-group">
                                <label>Escriba su apellido </label>
                                    <input type="text" id="apellidoedit"  >
                                    </label>
                                    
                                </div>
                                    
                                </p>
                                <p>
                                <div class="form-group">
                                <label>Escriba su DNI:</label>
                                    <input type="text" id="dniedit" >
                                    </label>
                                    
                                </div>
                                    
                                </p>
                                <p>
                                <div class="form-group">
                                    <label>Escriba su Cuil:</label>
                                    <input type="text" id="cuiledit" >
                                    </label>
                                    
                                </div>
                                    
                                </p>
                                
                                <p>Genero:
                                <div class="form-group">
                                    <label><input type="radio" id="sexoedit" value="femenino"> Mujer </label>
                                    <label><input type="radio" id="sexoedit" value="masculino"> Hombre </label>
                                    <label><input type="radio" id="sexoedit" value="otro"> Otro </label><br>
                                    
                                </div>                            
                                </p>
                                
                                
                                <p>
                                <div class="form-group">
                                <label>Fecha de Nacimiento</label>
                                    <input type="date" id="fchNacedit"  >
                                    </label>
                                    
                                </div>
                                    
                                </p>

                                <p>
                                <div class="form-group">
                                <label>Nacionalidad</label>
                                    <input type="text" id="nacionalidadedit" >
                                    </label>
                                    
                                </div>
                                    
                                </p>
                                <p>
                                <div class="form-group">
                                    <label>Nro. de cuenta</label>
                                    <input type="text" id="nro_cuentaedit"  >
                                    </label>
                                </div>
                                
                                </p>
                                
                                <button type="submit" class="btn btn-danger">Actualizar</button>

                            </form>
                        </div>

                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal EDITAR -->


        </div> 

        
        
        <hr>

    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" ></script>
    <script src="\autoparts_system\bootstrap-4.5.0\js\bootstrap.min.js"></script>
    <script src="\autoparts_system\bootstrap-4.5.0\js\jquery-3.5.1.min.js"></script>
    
    <script src="js/clientes.js"></script>
    <script>

        // function loadTabla(){
        //     // $('#editModal').modal('hide');

        //     $.get("php/tabla.php","",function(data){
        //         $("#listadoClientes").html(data);
        //     })

        // }

        // loadTabla();

    </script>

    <?php include("../../php/footer.php"); ?>
</body>
</html>